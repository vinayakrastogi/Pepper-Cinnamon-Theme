gsettings set org.cinnamon.theme name "cinnamon_pepper_yellow"
gsettings set org.gnome.desktop.background picture-uri 'file:///home/vinayak/Pictures/Wallpapers/Nordic/yellow.png'
