gsettings set org.cinnamon.theme name "cinnamon_pepper_white"
gsettings set org.gnome.desktop.background picture-uri 'file:///home/vinayak/Pictures/Wallpapers/Nordic/white.png'
